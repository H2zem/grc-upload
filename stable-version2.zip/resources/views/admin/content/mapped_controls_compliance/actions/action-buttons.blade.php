<a href="javascript:void(0);"
   class="submit-policy icon-link"
   data-row-id="{{ $row['row_id'] }}"
   data-control-id="{{ $row['control_id'] }}"
   data-policy-id="{{ $row['policy_id'] }}"
   data-policy-key="{{ $row['policy_key'] }}"
   title="Send Result">

    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
        viewBox="0 0 24 24" fill="none" stroke="currentColor"
        stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="22" y1="2" x2="11" y2="13"></line>
        <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
    </svg>
</a>

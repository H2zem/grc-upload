<link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/katex.min.css')) }}">
<link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/monokai-sublime.min.css')) }}">
<link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/quill.snow.css')) }}">
<link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/quill.bubble.css')) }}">
<style>
    body {
        background-color: #f4f4f4;
        /* Light gray background for the page */
    }

    .form-container {
        max-width: 100%;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        /* White background for the form container */
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .form-label {
        color: #333;
        /* Dark text for labels */
        font-weight: bold;
    }

    .form-control,
    .form-select {
        background-color: #f9f9fa;
        /* Light gray background for form controls */
        border: 1px solid #ced4da;
        /* Gray border for form controls */
        border-radius: 4px;
        color: #495057;
        /* Darker text color for input fields */
    }

    .form-control:disabled,
    .form-select:disabled {
        background-color: #f1f3f5;
        /* Slightly lighter gray for disabled fields */
    }

    .form-check-input:checked {
        background-color: #007bff;
        /* Blue color for checked radio buttons */
        border-color: #007bff;
    }

    .form-check-label {
        color: #333;
        /* Dark text for check labels */
    }

    .btn-primary {
        background-color: #007bff;
        /* Primary button color */
        border-color: #007bff;
        color: #fff;
        /* White text color for primary buttons */
    }

    .btn-primary:hover {
        background-color: #0056b3;
        /* Darker blue on hover */
        border-color: #004085;
    }

    .btn-outline-primary {
        color: #007bff;
        /* Blue color for outline buttons */
        border-color: #007bff;
    }

    .btn-outline-primary:hover {
        color: #0056b3;
        /* Darker blue on hover */
        border-color: #004085;
    }

    .error {
        color: #dc3545;
        /* Red color for error messages */
    }

    .text-muted {
        color: #6c757d;
        /* Light gray text for placeholder and secondary text */
    }

    .btn-guide {
        display: inline-block;
        padding: 8px 16px;
        font-size: 14px;
        font-weight: 500;
        color: #fff;
        background-color: #17a2b8;
        /* Blue color for guidance */
        border-radius: 4px;
        text-align: center;
        cursor: pointer;
        text-decoration: none;
        /* Remove underline for link */
        border: 1px solid #17a2b8;
        /* Match border with background color */
    }

    .btn-guide:hover {
        background-color: #138496;
        /* Darker shade on hover */
        border-color: #117a8b;
        /* Darker border on hover */
    }

    .btn-guide:focus {
        outline: none;
        /* Remove focus outline */
    }

    .clickable-link {
        color: #007bff;
        /* Bootstrap link color */
        text-decoration: underline;
        /* Underline to indicate clickable */
        cursor: pointer;
        /* Pointer cursor to indicate clickability */
    }

    .clickable-link:hover {
        color: #0056b3;
        /* Darker color on hover */
        text-decoration: none;
        /* Remove underline on hover */
    }

    .clickable-link i {
        font-size: 16px;
        /* Adjust size as needed */
        color: #007bff;
        /* Match link color */
    }
</style>
<div>
    <div class="container-fluid mt-4">
        <div class="form-container">
            {{-- <h4 class="text-center mb-4">{{ __('locale.Audit Update') }}</h4> --}}
            <form class="audit-update" id="submit-audit-update"
                action="{{ route('admin.compliance.ajax.aduit-details.updateCurrentAduit') }}" method="POST">
                @csrf
                <input type="hidden" name="id" value="{{ $id }}">
                <input type="hidden" value="{{ $existingUserOrTeam->responsible_type }}" name="responsible_type"
                    id="responsible_type">

                <div class="row gy-3">
                    <!-- Summary -->
                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label" for="summary">{{ __('locale.Summary') }}</label>
                            <textarea class="form-control" id="summary" rows="3" name="summary"
                                placeholder="{{ __('locale.Enter summary here...') }}" {{ $editable ? '' : 'disabled' }}>{{ $frameworkControlTestResult->summary }}</textarea>
                                <span class="text-danger error error-summary"></span>
                            </div>
                    </div>

                    <!-- Remediation Needed -->
                    <div class="col-12">
                        <label class="form-label d-block">{{ __('locale.Remediation Needed?') }}</label>
                        <div class="d-inline-block me-3">
                            <input class="form-check-input" type="radio" name="remediation" id="remediation_yes"
                                value="1" {{ $frameworkControlTestResult->remediation == '1' ? 'checked' : '' }}
                                {{ $editable ? '' : 'disabled' }}>
                            <label class="form-check-label ms-2" for="remediation_yes">{{ __('locale.Yes') }}</label>
                        </div>
                        <div class="d-inline-block">
                            <input class="form-check-input" type="radio" name="remediation" id="remediation_no"
                                value="0" {{ $frameworkControlTestResult->remediation == '0' ? 'checked' : '' }}
                                {{ $editable ? '' : 'disabled' }}>
                            <label class="form-check-label ms-2" for="remediation_no">{{ __('locale.No') }}</label>
                        </div>
                        @if ($frameworkControlTestResult->remediation != '0')
                            {{-- @if ($editable) --}}
                            <!-- Clickable span with arrow icon to trigger modal -->
                            <span class="clickable-link ms-3" data-bs-toggle="modal" data-bs-target="#remediationModal">
                                <i class="fas fa-arrow-right me-2"></i>{{ __('locale.Remediation Details') }}
                            </span>
                        @endif
                    </div>


                     <!-- Action Dropdown -->
                    <div class="col-xl-6 col-md-6 col-12">
                        <div class="form-group">
                            <label class="form-label" for="action_status">{{ __('compliance.AuditStatus') }}</label>
                            <select class="form-select" id="action_status" name="action_status"
                                {{ $editable ? '' : 'disabled' }}>
                                <option value="0"
                                    {{ $frameworkControlTestAudit->action_status == 0 ? 'selected' : '' }}>
                                    {{ __('locale.Open') }}
                                </option>
                                <option value="1"
                                    {{ $frameworkControlTestAudit->action_status == 1 ? 'selected' : '' }}>
                                    {{ __('locale.Closed') }}
                                </option>
                            </select>
                            <span class="text-danger error error-action_status"></span>
                        </div>
                    </div>

                    <!-- Teams -->
                    <div class="col-xl-6 col-md-6 col-12">
                        <div class="mb-1">
                            {{-- <br> --}}
                            @php
                                $label =
                                    $existingUserOrTeam->responsible_type == 'users'
                                        ? __('locale.Users')
                                        : __('locale.Teams');
                            @endphp

                            <label class="form-label" for="teams">{{ $label }}</label>

                            {{-- @foreach ($testTeamsNames as $team)
                                    <span class="badge rounded-pill badge-light-primary">{{$team}}</span>
                                @endforeach --}}
                            <select class="form-select multiple-select2" name="teams[]" id="teams"
                                multiple="multiple" {{ $editable ? '' : 'disabled' }}>
                                <option select disabled value="">{{ __('locale.select-option') }} </option>
                                @foreach ($teams as $team)
                                    <option value="{{ $team->id }}"
                                        {{ optionMultiSelect($team->id, $testTeams) }}>
                                        {{ $team->name }}</option>
                                @endforeach
                            </select>
                            <span class="error error-teams "></span>
                        </div>
                    </div>

                    @if ($editable)
                        <div class="col-12 d-flex justify-content-end mt-4">
                            <!-- Button to trigger modal -->
                            <button type="button" class="btn btn btn-primary me-2" data-bs-toggle="modal"
                                data-bs-target="#remediationModal">
                                {{ __('locale.Remediation Details') }}
                            </button>

                            <!-- Submit -->
                            <button type="button" id="submit-audit" class="btn btn-primary">
                                {{ __('locale.Submit') }}
                            </button>
                        </div>
                    @endif
                </div>
            </form>
        </div>
    </div>


</div>




<!-- Modal for Remediation Details -->
<div class="modal fade" id="remediationModal" tabindex="-1" aria-labelledby="remediationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">{{ __('locale.Remediation Details') }}</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>
             
            <div class="modal-body">
                <form id="remediationForm">
                    @csrf
                    <div class="row">
                        <!-- Select User -->
                        <div class="col-xl-6 col-md-6 col-12">
                            <div class="mb-1">
                                <label class="form-label"
                                    for="responsible_user">{{ __('locale.Responsible User') }}</label>
                                <select class="form-select" id="responsible_user" name="responsible_user"
                                    {{ $editable ? '' : 'disabled' }}>
                                    <option value="" disabled>{{ __('locale.select-option') }}</option>
                                    @foreach ($enabledUsers as $user)
                                        <option value="{{ $user->id }}"
                                            {{ (isset($remediationDetails) && $remediationDetails->responsible_user == $user->id) || $user->id == $controlOwner ? 'selected' : '' }}>
                                            {{ $user->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>




                        <!-- Budgetary -->
                        <div class="col-xl-6 col-md-6 col-12" disabled>
                            <div class="mb-1">
                                <label class="form-label" {{ $editable ? '' : 'disabled' }}
                                    for="budgetary">{{ __('locale.Budgetary') }}</label>
                                <input type="number" class="form-control" id="budgetary" name="budgetary" disabled
                                    value="{{ isset($remediationDetails) ? $remediationDetails->budgetary : '' }}">
                            </div>
                        </div>

                        <input type="hidden" name="controlTestId" value="{{ $id }}">
                        <!-- Status -->
                        <div class="col-xl-6 col-md-6 col-12" {{ $editable ? '' : 'disabled' }} disabled>
                            <div class="mb-1">
                                <label class="form-label" for="status">{{ __('locale.Status') }}</label>
                                <select class="form-select" id="status" name="status" disabled>
                                    <option value="" disabled>{{ __('locale.select-option') }}</option>
                                    <option value="1"
                                        {{ isset($remediationDetails) && $remediationDetails->status == 1 ? 'selected' : '' }}>
                                        {{ __('locale.Approved') }}
                                    </option>
                                    <option value="2"
                                        {{ isset($remediationDetails) && $remediationDetails->status == 2 ? 'selected' : '' }}>
                                        {{ __('locale.Rejected') }}
                                    </option>
                                    <!-- Add more status options as needed -->
                                </select>
                            </div>
                        </div>


                        <!-- Due Date -->
                        <div class="col-xl-6 col-md-6 col-12" {{ $editable ? '' : 'disabled' }} disabled>
                            <div class="mb-1">
                                <label class="form-label" for="due_date">{{ __('locale.Due Date') }}</label>
                                <input type="date" class="form-control flatpickr-date-time-compliance"
                                    id="due_date" name="due_date"
                                    value="{{ isset($remediationDetails) ? $remediationDetails->due_date : '' }}">
                            </div>
                        </div>



                        <!-- Comments -->
                        <div class="col-12" {{ $editable ? '' : 'disabled' }} disabled>
                            <div class="mb-1">
                                <label class="form-label" for="comments">{{ __('locale.Comments') }}</label>
                                <textarea class="form-control" id="comments" name="comments" rows="2">{{ isset($remediationDetails) ? $remediationDetails->comments : '' }}</textarea>
                            </div>
                        </div>


                        <div class="mb-1">
                            <label class="form-label">{{ __('locale.Corrective') }}</label>
                            <div id="corrective_action_plan_editor" style="height:100px;">
                                {!! isset($remediationDetails) ? $remediationDetails->corrective_action_plan : '' !!}
                            </div>
                        </div>
                        <input type="hidden" name="corrective_action_plan" id="corrective_action_plan_hidden">



                    </div>
                </form>
            </div>
            @if ($editable)
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">{{ __('locale.Close') }}</button>
                    <button type="button" class="btn btn-primary"
                        id="saveChangesBtnRemidation">{{ __('locale.Save Changes') }}</button>
                </div>
            @endif
        </div>
    </div>
</div>
<script src="{{ asset('cdn/jquery6.js') }}"></script>
<script src="{{ asset(mix('vendors/js/editors/quill/quill.min.js')) }}"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const remediationYes = document.getElementById('remediation_yes');
        const remediationModal = new bootstrap.Modal(document.getElementById('remediationModal'));

        remediationYes.addEventListener('change', function() {
            if (this.checked) {
                remediationModal.show();
            }
        });
    });

    $(document).ready(function() {
        var quill = new Quill('#corrective_action_plan_editor', {
            theme: 'snow',
            modules: {
                toolbar: [
                    [{
                        'header': [1, 2, 3, 4, 5, 6, false]
                    }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{
                        'list': 'ordered'
                    }, {
                        'list': 'bullet'
                    }],
                    [{
                        'indent': '-1'
                    }, {
                        'indent': '+1'
                    }],
                    [{
                        'direction': 'rtl'
                    }],
                    ['clean'],
                ],
            },
        });

        $('#saveChangesBtnRemidation').on('click', function() {
            // Get the HTML content from Quill editor
            var correctiveActionPlan = quill.root.innerHTML;

            // Store the HTML content in the hidden input field
            $('#corrective_action_plan_hidden').val(correctiveActionPlan);

            // Serialize form data
            var formData = $('#remediationForm').serialize();

            $.ajax({
                url: "{{ route('admin.compliance.ajax.remediation-details.store') }}",
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        makeAlert('success', response.message,
                            "{{ __('locale.Success') }}");
                        $('#remediationModal').modal('hide'); // Hide the modal
                    } else {
                        showError(response.errors);
                    }
                },
                error: function(response) {
                    var responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
                    showError(responseData.errors);
                }
            });
        });
    });

    $(document).ready(function() {
    $('#submit-audit').on('click', function(e) {
        e.preventDefault(); // Prevent default form submission

        var form = $('#submit-audit-update');
        var data = new FormData(form[0]);
        var url = form.attr('action');

        $.ajax({
            url: url,
            type: 'POST',
            data: data,
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                makeAlert('success', response.message, "{{ __('locale.Success') }}");
            },
            error: function(xhr) {
                var responseData = xhr.responseJSON;

                makeAlert('error', responseData.message || "{{ __('locale.Error') }}", "{{ __('locale.Error') }}");

                // Clear previous errors
                $('.text-danger.error').text('');

                if (responseData.errors) {
                    $.each(responseData.errors, function(key, value) {
                        var errorSpan = $('.error-' + key);
                        if (errorSpan.length) {
                            errorSpan.text(value[0]); // Display the first error message
                        }
                    });
                }
            }
        });
    });
});

</script>
